package util;

import java.io.File;

import static util.ExceptionHandler.err;

public class ArgParser {

    public static File extractTarget(String[] s) {

        /* Check validity of arguments:
         * 1. must be exactly one argument
         * 2. must be directory
         */
        if (s.length != 1) {
            err("User must provide exactly one argument"
                    + System.lineSeparator()
                    + "Usage: java -jar IR_P01.jar [path-to-document-folder]");
        }

        File file = new File(s[0]);

        if (!file.isDirectory()) {
            err("Argument must be a directory");
        }

        return file;
    }
}
