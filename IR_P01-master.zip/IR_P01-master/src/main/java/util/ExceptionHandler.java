package util;

public class ExceptionHandler {

    public static void err(String e) {
        System.err.println("[ERROR] " + e);
        System.exit(1);
    }

    public static void warn(String w) {
        System.err.println("[WARNING] " + w);
    }

}
