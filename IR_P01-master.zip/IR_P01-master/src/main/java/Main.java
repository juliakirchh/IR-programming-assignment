import index.IndexBuilder;
import index.LocalIndexSearcher;
import util.ArgParser;

import java.io.File;

public class Main {

    public static void main(String[] args) {

        /*
         * Extract the target directory from the environment arguments
         * Exits if the given argument does not match the expectations
         */
        File target = ArgParser.extractTarget(args);

        /* Build a new index from the given directory */
        IndexBuilder ib = new IndexBuilder(target);

        /* Process user query */
        LocalIndexSearcher lis = new LocalIndexSearcher(ib);
        while (true) {
            lis.userSearch();
        }
    }

}
