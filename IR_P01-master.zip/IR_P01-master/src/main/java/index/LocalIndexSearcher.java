package index;

import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.MMapDirectory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import static util.ExceptionHandler.err;

public class LocalIndexSearcher {
    private IndexSearcher searcher;

    /* Processing user query */
    public LocalIndexSearcher(IndexBuilder ib) {
        /*
         * Initialize IndexSearcher by opening the index directory in memory
         */
        try {
            searcher = new IndexSearcher(DirectoryReader.open(MMapDirectory.open(ib.getIndex_dir())));
        } catch (java.io.IOException e) {
            err("Could not open index directory");
        }

    }

    public void userSearch() {
        /*
         * Build new Query from pre-processed user input
         * Pre-processing is done in the same way as for the IndexBuilder
         */
        String query_string = readInput();
        Query query = null;
        try {
            query = new QueryParser("content", new EnglishAnalyzer()).parse(query_string);
        } catch (org.apache.lucene.queryparser.classic.ParseException e) {
            err("Could not parse query");
        }

        /*
         * IndexSearcher searches the index and stores up to 10 best results
         */
        ScoreDoc[] hits = null;
        try {
            hits = searcher.search(query, 10).scoreDocs;
        } catch (java.io.IOException e) {
            err("Could not search index");
        }

        printResults(hits);
    }

    /* Read user input into a String */
    private String readInput() {
        System.out.print("------------\nEnter query: "
                + System.lineSeparator());
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String query_string = null;
        try {
            query_string = br.readLine();
        } catch (java.io.IOException e) {
            err("Could not read user input");
        }

        return query_string;
    }

    /* Print result in a more or less aesthetical way */
    private void printResults(ScoreDoc[] hits) {
        if (hits.length == 0) {
            System.out.println("--------\nno search results, try another term");
            return;
        }
        System.out.println("--------\n\rResults:\n\r--------");
        for (int i = 0; i < hits.length; i++) {
            Document d = null;
            try {
                d = searcher.doc(hits[i].doc);
            } catch (java.io.IOException e) {
                err("Could not retrieve document");
            }

            /*
             * format:
             * $RANK $RELATIVE_PATH $LAST_MODIFIED_DATE $SCORE
             * for HTML files the following is appended:
             * $TITLE $SUMMARY
             */
            String result = String.format("%2d. %-100s %50s %10sscore=%.5f %10s", (i + 1), d.get("path"), d.get("last-modified"), "", hits[i].score, "");
            if (d.get("file-type").equals("html")) {
                result = result + String.format("%-20s %-30s", d.get("title"), d.get("summary"));
            }
            System.out.println(result);
        }
    }
}
