package index;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.MMapDirectory;
import org.jsoup.Jsoup;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Date;

import static util.ExceptionHandler.err;
import static util.ExceptionHandler.warn;

public class IndexBuilder {

    private IndexWriter writer;
    private Path index_dir;

    public IndexBuilder(File target) {
        /* Create a temporary directory for the index
         * located in the OS' standard tmp directory.
         * The directory will be deleted after the JVM exits.
         */
        try {
            index_dir = Files.createTempDirectory("IR_P01_IRS");
        } catch (java.io.IOException e) {
            err("Could not create temporary directory");
        }
        index_dir.toFile().deleteOnExit();

        /* Create a new index in temp dir */
        try {
            writer = new IndexWriter(MMapDirectory.open(index_dir), new IndexWriterConfig());
        } catch (java.io.IOException e) {
            err("Could not create index");
        }

        /* Index content of directory
         * then close the index so that the change is written
         */
        indexDirectory(target);

        /* close writer */
        try {
            writer.close();
        } catch (java.io.IOException e) {
            warn("Could not close IndexWriter");
        }
    }

    Path getIndex_dir() {
        return index_dir;
    }

    /*
     * Process directories
     */
    private void indexDirectory(File d) {
        for (File f : d.listFiles()) {
            if (f.isDirectory()) {
                indexDirectory(f);
            } else {
                indexFile(f);
            }
        }
    }

    /*
     * Process single files
     */
    private void indexFile(File f) {
        /*
         * Exclude non-txt or -html files from indexing
         */
        if (f.toString().endsWith(".txt") || f.toString().endsWith(".html")) {
            FileReader reader;
            try {
                reader = new FileReader(f);
            } catch (FileNotFoundException e) {
                warn(f.toString() + " not found");
                return;
            }

            /*
             * Create new Document adding following fields:
             * path: relative path of the file
             * last-modified: modification date of the file
             * file-type: type of the file (txt/html)
             * content: - the whole content of the file >for txt files
             *          - the content of the body tag   >for html files
             * title: content of title html tag
             * date: content of date html tag
             * summary: content of summary html tag
             */
            Document doc = new Document();
            doc.add(new StringField("path", f.toString(), Field.Store.YES));
            doc.add(new StringField("last-modified", new Date(f.lastModified()).toString(), Field.Store.YES));

            EnglishAnalyzer analyzer = new EnglishAnalyzer();
            TokenStream ts = null;

            /* Use the EnglishAnalyzer to pre-process the content of the reader in the following way:
             * 1. convert to lowercase
             * 2. apply stopword filter
             * 3. apply Porter stemmer
             * see https://github.com/apache/lucene-solr/blob/master/lucene/analysis/common/src/java/org/apache/lucene/analysis/en/EnglishAnalyzer.java
             */

            if (f.toString().endsWith(".html")) {
                String bodyTag = indexHTMLFile(doc, f);
                doc.add(new StringField("file-type", "html", Field.Store.YES));
                StringReader sr = new StringReader(bodyTag);
                ts = analyzer.tokenStream("", sr);

            } else {
                doc.add(new StringField("file-type", "txt", Field.Store.YES));
                ts = analyzer.tokenStream("", reader);
            }

            doc.add(new TextField("content", ts));

            try {
                writer.addDocument(doc);
            } catch (IOException e) {
                warn("Could not add " + f.toString() + " to index");
            }

            /* close reader */
            try {
                reader.close();
            } catch (IOException e) {
                warn("Could not close reader");

            }
            System.out.println("Added " + f.toString());
        }
    }

    private String indexHTMLFile(Document doc, File file) {
        org.jsoup.nodes.Document htmlDoc = null;
        String metadesc = null;

        try {
            htmlDoc = Jsoup.parse(file, "UTF-8");
        } catch (Exception e) {
            warn("Could not parse html file");
        }

        try { // not all html pages have a meta tag with a description
            // the summary is saved in the head part of the document and looks like this : <meta name="Description" content="example">
            metadesc = htmlDoc.select("meta[name=description]").attr("content"); // use this meta tag as a summary
        } catch (Exception e) {
            warn("Failed trying to retrieve the meta description");
        }

        if (metadesc.length() < 1) {
            metadesc = "no summary for this page";
        }

        doc.add(new StringField("title", htmlDoc.title(), Field.Store.YES));
        doc.add(new StringField("date", new Date(file.lastModified()).toString(), Field.Store.NO));
        // just adding the last modified date because HTML pages don't have a <date> tag
        // Field.Store.NO : this field will not be returned in the search results
        doc.add(new StringField("summary", metadesc, Field.Store.YES));

        Element htmlBody = htmlDoc.body();

        if (htmlBody == null) {
            return "";
        } else {
            return htmlDoc.body().text();
        }
    }
}

