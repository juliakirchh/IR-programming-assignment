# IR_P01
a simple command line based search engine for txt and html files written in java with apache lucene and Jsoup. 
Part of a homework assignment for Information Retrieval
